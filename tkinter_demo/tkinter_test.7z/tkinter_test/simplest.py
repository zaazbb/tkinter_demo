
import tkinter
l = tkinter.Label(text = "See me?")
l.pack()
l.mainloop()

##import tkinter
##m = tkinter.Tk()
##m.mainloop()


# command.
##python -m tkinter
##
##import tkinter
##tkinter._test()
##
### in shell.
##tkinter.Tcl().eval('info patchlevel')

# will return x11, win32 or aqua
##root.tk.call('tk', 'windowingsystem')

# tik ver.
##from tkinter import tix
##root = tix.Tk()
##root.tk.eval('package require Tix')

