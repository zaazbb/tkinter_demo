
from tkinter import tix
from tkinter.constants import *

root = tix.Tk()

w = tix.HList       (root)
w.pack()
w.mainloop()
