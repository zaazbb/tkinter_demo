#!/bin/sh
""":"
exec python $0 ${1+"$@"}
"""

# ------------------- HelloMagnifier.py -------------------
# 
# This program demonstrates how to implement possibilities
# for zooming in and out using the mouse. To zoom, drag and 
# mark a rectangle with the mouse. Left button zooms in, and
# right button zooms out.
# 

from Tkinter import *        # The Tk package
import Pmw                   # The Python MegaWidget package
import math                  # import the sin-function

master = Tk()                # build Tk-environment
ncurves = 4                  # draw 4 curves
npoints = 32                 # use 32 points on each curve

def zoom(x0, y0, x1, y1):
    g.xaxis_configure(min=x0, max=x1)
    g.yaxis_configure(min=y0, max=y1)
    
def mouseDrag(event):
    global x0, y0, x1, y1
    (x1, y1) = g.invtransform(event.x, event.y)
         
    g.marker_configure("marking rectangle", 
	coords = (x0, y0, x1, y0, x1, y1, x0, y1, x0, y0))
    
def mouseUp(event):
    global dragging
    global x0, y0, x1, y1
    
    if dragging:
	g.unbind(sequence="<Motion>")
	g.marker_delete("marking rectangle")
	
	if x0 <> x1 and y0 <> y1:

            # make sure the coordinates are sorted
            if x0 > x1: x0, x1 = x1, x0
            if y0 > y1: y0, y1 = y1, y0
     
	    if event.num == 1:
	       zoom(x0, y0, x1, y1) # zoom in
	    else:
	       (X0, X1) = g.xaxis_limits()
	       k  = (X1-X0)/(x1-x0)
	       x0 = X0 -(x0-X0)*k
	       x1 = X1 +(X1-x1)*k
	       
	       (Y0, Y1) = g.yaxis_limits()
	       k  = (Y1-Y0)/(y1-y0)
	       y0 = Y0 -(y0-Y0)*k
	       y1 = Y1 +(Y1-y1)*k
	       
	       zoom(x0, y0, x1, y1) # zoom out
	   	    
def mouseDown(event):
    global dragging, x0, y0
    dragging = 0
    
    if g.inside(event.x, event.y):
        dragging = 1
        (x0, y0) = g.invtransform(event.x, event.y)
        
        g.marker_create("line", name="marking rectangle", dashes=(2, 2))
	g.bind(sequence="<Motion>",  func=mouseDrag)
            

############################## main program ################################

if not Pmw.Blt.haveblt(master):     # Is Blt installed?
   print("BLT is not installed!")

else:
   vector_x = []    # make vector for x-axis
   vector_y = []
   for y in range(ncurves): 
      vector_y.append([])                      # make list of curves
   
   for x in range(npoints+1):                  # for each point...
      vector_x.append(x*0.1)                   # compute the x value

      # fill vectors with cool graphs
      for c in range(ncurves):                 # for each curve...
         vector_y[c].append(math.sin(c*x*0.1)) # compute the y value
         
   g = Pmw.Blt.Graph(master)                   # make a new graph area
   g.pack(expand=1, fill='both')
   
   color = ['red', '#ff9900', 'blue', '#00cc00', 'black', 'grey']
   
   for c in range(ncurves):                    # for each curve...
      curvename = 'sin(' + str(c) +'x)'        # make a curvename
      g.line_create(curvename,                 # and create the graph
                    xdata=tuple(vector_x),     # with x data,
                    ydata=tuple(vector_y[c]),  # and  y data
                    color=color[c],            # and a nice color
                    linewidth=2,               # and fat lines
                    symbol='')                 # and no markers
   
   g.bind(sequence="<ButtonPress>",   func=mouseDown)
   g.bind(sequence="<ButtonRelease>", func=mouseUp  )
   
   # enter a title
   g.configure(title='Hello Magnifier\nDrag to magnify. Left: zoom in, right: zoom out')     
   
   master.mainloop()                            # ...and wait for input




