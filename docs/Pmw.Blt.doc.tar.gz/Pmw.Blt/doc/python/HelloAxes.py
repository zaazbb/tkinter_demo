#!/bin/sh

""":"
exec python $0 ${1+"$@"}
"""

# ---------------------- HelloAxis.py ----------------------
# 
# This program demonstrates all methods available for axes.
# Note that this program does not do anything useful;
# its purpose is to try out functionality only.
# 


from Tkinter import *        # The Tk package
import Pmw                   # The Python MegaWidget package
import math                  # import the sin-function

master = Tk()                # build Tk-environment
ncurves = 4                  # draw 4 curves
npoints = 32                 # use 32 points on each curve


if not Pmw.Blt.haveblt(master):     # Is Blt installed?
   print("BLT is not installed!")

else:
   vector_x = []   # make vector for x-axis
   vector_y = []

   for y in range(ncurves):
      vector_y.append([])              

   for x in range(npoints+1):          
      vector_x.append(x*0.1)           

      # fill vectors with cool graphs
      for c in range(ncurves):         
         vector_y[c].append(math.sin(c*x*0.1))

   g = Pmw.Blt.Graph(master)                  
   g.pack(expand=1, fill='both')

   for c in range(ncurves):                   
      curvename = 'sin(' + str(c) +'x)'       
      g.line_create(curvename,                
                    xdata=tuple(vector_x),   
                    ydata=tuple(vector_y[c]),
                    symbol='')               
   
   g.configure(title='Hello Axes')            

   
   ############################## axis_cget ###############################
   
   print "xaxis color: ", g.axis_cget("x", "color")

   # alternatively, you can fetch x,y,x2,y2 axes directly:
   print "yaxis color: ", g.yaxis_cget("color")
   
   ############################ axis_configure #############################
   
   g.axis_configure("y", color="red") # set yaxis option color
   alloptions = g.axis_configure("x") # get all xaxis options
   print "get yaxis option color: ", g.axis_configure("y", "color")
   
   # alternatively: make the calls directly on the axis:
   g.xaxis_configure(color="red") # set xaxis option color
   alloptions = g.xaxis_configure() # get all xaxis options
   print "get xaxis option color: ", g.xaxis_configure("color")
   
   # print all options
   print "all options:",
   for option in alloptions.keys():
      print option + ",",
   print "\n"
   
   # Example of setting the labels on the yaxis:
   def axislabels(pathname, value):
       return  "y="  + str(value)
   
   g.yaxis_configure(command=axislabels)
   
   # note: older versions call this option limits rather than limitsformat
   g.axis_configure("x", limitsformat=("min: %4.2fkm", "max: %4.2fkm"))


   ############################### axis_create ############################  
   g.axis_create("myOwnAxis", color="green", subdivisions=5)

   ################################ axis_use ##############################
   g.y2axis_use("myOwnAxis") # ..and use the new axis as second y-axis

   # ...and map the sin(x) function to the new axis.
   g.element_configure("sin(1x)",  mapy="myOwnAxis")

   ################################ axis_delete ###########################   
   g.axis_delete("myOwnAxis") # Axis won't be deleted since it is in use.
   
   ################################ axis_limits ###########################
   axislim = g.axis_limits("x")
   print "axis limits are:", axislim
    
   ################################# axis_names ###########################
   allNames = g.axis_names() # retrieve all names.
   someNames = g.axis_names("x*", "y") # get all x-axes and the y-axis.
   print "some axis names: "
   
   for name in someNames:
       print name +",",
   print "\n"
   
   ################ axis_transform, axis_invtransform #####################
   def transformer(event):
       (x,y) = (event.x, event.y)
       print "(%d,%d)" %(x,y),
       
       # inversetransform clicked pos to get axis-coordinates.
       (x,y) = (g.xaxis_invtransform(x), g.yaxis_invtransform(y))
       print "--> (%f,%f)" %(x,y),

       # transform back to get original window-coordinates.
       # (not always exact because of round-off errors.)
       (x,y) = (g.xaxis_transform(x), g.yaxis_transform(y))
       print "--> (%d,%d)" %(x,y)
   
   g.bind("<ButtonPress>", transformer)

   master.mainloop()



