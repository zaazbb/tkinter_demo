#!/bin/sh

""":"
exec python $0 ${1+"$@"}
"""

# --------------------- HelloLegends.py ---------------------
# 
# This program demonstrates all methods available for the legends.
# Note that this program does not do anything useful;
# its purpose is to try out functionality only.
# 


from Tkinter import *        # The Tk package
import Pmw                   # The Python MegaWidget package
import math                  # import the sin-function

master = Tk()                # build Tk-environment
ncurves = 4                  # draw 4 curves
npoints = 32                 # use 32 points on each curve


if not Pmw.Blt.haveblt(master):     # Is Blt installed?
   print("BLT is not installed!")

else:
   vector_x = []   # make vector for x-axis
   vector_y = []

   for y in range(ncurves):
     vector_y.append([])                  

   for x in range(npoints+1):             
      vector_x.append(x*0.1)              

      # fill vectors with cool graphs
      for c in range(ncurves):            
         vector_y[c].append(math.sin(c*x*0.1))

   g = Pmw.Blt.Graph(master)                  
   g.pack(expand=1, fill='both')

   for c in range(ncurves):                   
      curvename = 'sin(' + str(c) +'x)'       
      g.line_create(curvename,                
                    xdata=tuple(vector_x),   
                    ydata=tuple(vector_y[c]),
                    symbol='')               
   
   g.configure(title='Hello Legend')          
   
   ############ legend_get, legend_deactivate, legend_activate ##############
   activeLegends = {}
   g.pen_configure("activeLine", symbol="scross")
   
   def mouseDown(event):
       global activeLegends
       
       pos = "@" +str(event.x) +"," +str(event.y)
       legend = g.legend_get(pos)    # get the selected legend.
       
       if activeLegends.has_key(legend):
           g.legend_deactivate(legend)      # deactivate the legend
           g.element_deactivate(legend)     # deactivate the data as well
           del activeLegends[legend]        # remove key from dictionary 
       else:
           g.legend_activate(legend)        # mark the new legend.
           g.element_activate(legend)       # mark the data as well
           activeLegends[legend] = 1        # set a mark in the dictionary

   ############################### legend_bind ##############################
   def dummyfunc(event):
       print "dummy"
   
   g.legend_bind("all", "<ButtonPress>", mouseDown)
   g.legend_bind("all", "<ButtonRelease>", dummyfunc)
   
   ############################## legend_unbind #############################
   g.legend_unbind("all", "<ButtonRelease>") # cancel last binding.
   

   ############################### legend_cget ##############################
   anchor = g.legend_cget("anchor")
   print "Current anchor position: ", anchor
   
   ############################# legend_configure ###########################
   all = g.legend_configure()
   print "all options:",
   for option in all.keys():
       print option,
       
   print "\n"
   
   # set some configuration options.
   g.legend_configure(anchor="ne", 
                      background="lightblue",
                      activebackground="blue",
                      position="@400,50")
   
   
   # set a custom name for this graph. This will be used in the legend.
   g.element_configure("sin(1x)", label="custom") 

	   
   master.mainloop()
   



