#!/bin/sh

""":"
exec python $0 ${1+"$@"}
"""

# -------------------- HelloPostscript.py --------------------
# 
# This program demonstrates all methods available for
# transforming the graph to postscript code (e.g. for hardcopy).
# Note that this program does not do anything useful;
# its purpose is to try out functionality only.
# 



from Tkinter import *        # The Tk package
import Pmw                   # The Python MegaWidget package
import math                  # import the sin-function

master = Tk()                # build Tk-environment
ncurves = 4                  # draw 4 curves
npoints = 32                 # use 32 points on each curve


if not Pmw.Blt.haveblt(master):     # Is Blt installed?
   print("BLT is not installed!")

else:
   vector_x = []   # make vector for x-axis
   vector_y = []

   for y in range(ncurves):
     vector_y.append([])                    

   for x in range(npoints+1):               
      vector_x.append(x*0.1)                

      # fill vectors with cool graphs
      for c in range(ncurves):              
         vector_y[c].append(math.sin(c*x*0.1))

   g = Pmw.Blt.Graph(master)                  
   g.pack(expand=1, fill='both')

   for c in range(ncurves):                   
      curvename = 'sin(' + str(c) +'x)'       
      g.line_create(curvename,                
                     xdata=tuple(vector_x),   
                     ydata=tuple(vector_y[c]),
                     symbol='')               
   
   g.configure(title='Hello Postscript')      
   
   
   ########################## postscript_cget ############################
   pheight = g.postscript_cget("paperheight")
   print "Default paperheight: ", pheight
   
   ######################## postscript_configure #########################
   all = g.postscript_configure()
   
   print "All available options: ",
   for option in all.keys():
       print option,
       
   print "\n"
   
   
   # alter the default postscript settings:
   g.postscript_configure(
      center = 0,                    # place plot in upper left corner
      colormode="gray",              # grayscale rather than colors
      decorations=0)                 # and no decorations.
      
   ps = g.postscript_output()        # get the ps-code
   print ps                          # print it to screen
   
   g.postscript_output("tmp.ps")     # ..or more naturally, save it to file.
   
   
   master.mainloop()





