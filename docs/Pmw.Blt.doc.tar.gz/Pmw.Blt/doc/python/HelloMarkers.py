#!/bin/sh

""":"
exec python $0 ${1+"$@"}
"""

# -------------------- HelloMarkers.py --------------------
# 
# This program demonstrates all methods available for markers.
# Note that this program does not do anything useful;
# its purpose is to try out functionality only.
# 



from Tkinter import *        # The Tk package
import Pmw                   # The Python MegaWidget package
import math                  # import the sin-function

master = Tk()                # build Tk-environment
ncurves = 4                  # draw 4 curves
npoints = 32                 # use 32 points on each curve


if not Pmw.Blt.haveblt(master):     # Is Blt installed?
   print("BLT is not installed!")

else:
   vector_x = []   # make vector for x-axis
   vector_y = []

   for y in range(ncurves):
     vector_y.append([])                      

   for x in range(npoints+1):                 
      vector_x.append(x*0.1)                  

      # fill vectors with cool graphs
      for c in range(ncurves):                
         vector_y[c].append(math.sin(c*x*0.1))

   g = Pmw.Blt.Graph(master)                  
   g.pack(expand=1, fill='both')

   for c in range(ncurves):                   
      curvename = 'sin(' + str(c) +'x)'       
      g.line_create(curvename,                
                    xdata=tuple(vector_x),   
                    ydata=tuple(vector_y[c]),
                    symbol='')             
   
   g.configure(title='Hello Markers')      
   
   ########################## marker_create ############################
   g.marker_create("text", name="theText" )
   g.marker_create("line", name="theArrow")
   g.marker_create("bitmap", name="theBitmap")
   g.marker_create("image", name="theImage")
   g.marker_create("polygon", name="thePolygon")
   g.marker_create("window", name="theWindow")
   
   ######################### marker_configure ##########################
   g.marker_configure("theText", 
                       coords=(0.2, 0.9),
                       text="a comment",
                       background="lightblue")
                       
                       
   g.marker_configure("theArrow",
   		       coords=(0.2, 0.8, 0.35, 0.67, 0.35, 0.72,
                               0.35, 0.67, 0.28, 0.67),
   		       outline="red")
   		       
   g.marker_configure("theBitmap", 
                       background="lightblue",
                       foreground="blue",
                       coords=(1.5, 0.7),
                       bitmap = "questhead") 
   
   img = PhotoImage(file = 'blueball.gif', master=master)
   g.marker_configure("theImage",
                       coords=(2.0, 0.6),
                       image=img)

   coords = ()
   for i in range(5): # make a star
       x = 2.0 +0.2*math.sin(math.pi*i*0.8)
       y = 0.6 +0.2*math.cos(math.pi*i*0.8)
       coords = coords + (x, y)
   
   g.marker_configure("thePolygon",
   		       coords= coords,
   		       fill="lightblue",
   		       linewidth=1,
   		       outline="blue")
   		       
   b = Button(g, text="Quit!", command=master.quit)
   g.marker_configure("theWindow", 
                       coords=(0.3, -0.85),
                       window=b)
   		       
   		       
   ######################### marker_before ##########################

   # put the image in front of the polygon
   g.marker_before("thePolygon", "theImage") 
   
   ######################### marker_after ###########################
   # put the polygon after the image  (no change)
   g.marker_after("theImage", "thePolygon")
   
   ######################### marker_bind ############################
   def mouseMove(event):
       coords = g.invtransform(event.x, event.y)
       g.marker_configure("theBitmap", coords=coords)
   
   # bind the bitmap to mouse-motion event, so that it follows the
   # mouse as long as the mouse is over it.
   g.marker_bind("theBitmap", "<Motion>", mouseMove)	
   g.marker_bind("theText",   "<Motion>", mouseMove) # bind another
   
   ######################## marker_unbind ############################
   g.marker_unbind("theText", "<Motion>") # cancel the Text-bind.
   
   ######################### marker_cget #############################
   coords = g.marker_cget("thePolygon", "coords")
   print "coords of the polygon: ", coords
   
   ######################### marker_delete ############################
   g.marker_create("text", name="text2", coords=(1,1), text="dummy")
   g.marker_delete("text2") # delete the marker.
   

   ########################## marker_exists ###########################
   if g.marker_exists("theBitmap"):
       print 'marker "theBitmap" exists'
   else:
       print 'marker "theBitmap" does not exist'
       
   ########################### marker_names ###########################
   all = g.marker_names()
   some = g.marker_names("*g*") # get all that contains a 'g'
   
   print "all bitmaps containing a g are:",
   
   for key in some:
       print key,
       
   print "\n"
   
   ########################## marker_type ##############################
   type = g.marker_type("thePolygon")
   print "the polygon is of type:", type
   
   master.mainloop()

   


