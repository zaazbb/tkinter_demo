#!/bin/sh

""":"
exec python $0 ${1+"$@"}
"""

# --------------------- HelloElements.py ---------------------
# 
# This program demonstrates all methods available for elements (curves).
# Note that this program does not do anything useful;
# its purpose is to try out functionality only.
# 


from Tkinter import *        # The Tk package
import Pmw                   # The Python MegaWidget package
import math                  # import the sin-function

master = Tk()                # build Tk-environment
ncurves = 4                  # draw 4 curves
npoints = 32                 # use 32 points on each curve


if not Pmw.Blt.haveblt(master):     # Is Blt installed?
   print("BLT is not installed!")

else:
   vector_x = []   # make vector for x-axis
   vector_y = []

   for y in range(ncurves):
     vector_y.append([])                

   for x in range(npoints+1):           
      vector_x.append(x*0.1)            

      # fill vectors with cool graphs
      for c in range(ncurves):          
         vector_y[c].append(math.sin(c*x*0.1)) 

   g = Pmw.Blt.Graph(master)                   
   g.pack(expand=1, fill='both')

   for c in range(ncurves):                    
      curvename = 'sin(' + str(c) +'x)'        
      g.line_create(curvename,              
                    xdata=tuple(vector_x),  
                    ydata=tuple(vector_y[c]), 
                    symbol='')                
   
   g.configure(title='Hello Elements')
   
   ########################## element_activate #########################
   g.element_activate("sin(1x)", 5, 6, 7, 8, 9, 10, 11, 17, 18, 19)
   g.element_activate("sin(2x)")               # activate all points
   g.pen_configure("activeLine", symbol="cross") # configure active points
   
   ######################### element_deactivate ########################
   g.element_deactivate("sin(2x)") # deactivate all points
   
   ########################## element_closest ##########################
   def mouseDown(event):
       dict = g.element_closest(event.x, event.y, halo=5, interpolate=1)
       if dict <> None:	
          g.element_activate(dict["name"], dict["index"]) # activate it
   
   ########################### element_bind ############################
   def mouse2(event):
       print "fired a second handler."
   
   # Bind mouseDown to all graphs. Click to activate a point on each graph.
   g.element_bind("all",       "<ButtonPress>", mouseDown)
   
   # Add an extra handler to the sin(1x) graph.
   g.element_bind("sin(1x)", "<ButtonPress>", mouse2, add=1)
   
   ########################### element_unbind ##########################
   g.element_unbind("sin(1x)", "<ButtonPress>") # remove it again.

   ############################ element_cget ###########################
   w = g.element_cget("sin(2x)", "linewidth")
   print "Current linewidth: ", w

   ########################## element_configure ########################
   g.element_configure( "sin(3x)", 
      color   = "red",
      dashes  = 1,
      symbol  = "circle")
   
   
   ########################### element_delete ###########################   
   g.element_delete("sin(0x)") # delete the 1st graph.
   
   ########################### element_exists ###########################
   if g.element_exists("sin(0x)"):
       print "warning: element was not deleted."
   else:
       print "element deleted."
        
   ########################### element_names ############################
   allnames  = g.element_names()
   somenames = g.element_names("sin*") # fetch all sinus graphs
   
   print "existing elements:",
   
   for name in somenames:
       print name +",",
       
   print "\n"
   
   ############################ element_show #############################
   all = g.element_show() # get the displaylist.
   
   new = ()
   for element in all:
       new = (element,) +new # revert the displaylist
       
   g.element_show(new) # display the graphs in reverse order.
   
   ############################ element_type #############################
   type = g.element_type(element) # get the type of the last element above
   
   print element, "is of type:", type 
   
   # Note: all our graphs are of type 'line'. For an example of the 
   # 'bar'-type see the HelloGraph.py file.
   
   master.mainloop()
   



