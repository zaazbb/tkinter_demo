# ---------------------- HelloWorld1.py ----------------------
# 
# This program demonstrates the simplest possible 
# BLT Graph program.
# 

from Tkinter import *           # The Tkinter package
import Pmw                      # The Python MegaWidget package
master = Tk()                   # build Tk-environment

g = Pmw.Blt.Graph(master)       # make a new graph area
g.pack(expand=1, fill='both')
 
# Make a set of x- and y-coordinates
vector_x = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
vector_y = (5, 4, 3, 2, 1, 0, 1, 2, 3, 4, 5)

# create graph with label, x-data, and y-data
g.line_create("f(x)=abs(x-5)", xdata=vector_x, ydata=vector_y)

master.mainloop()  # the event loop...


