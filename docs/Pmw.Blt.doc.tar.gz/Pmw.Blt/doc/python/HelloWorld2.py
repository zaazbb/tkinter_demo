#!/bin/sh

""":"
exec python $0 ${1+"$@"}
"""

# ---------------------- HelloWorld2.py ----------------------
# 
# This program demonstrates the most basic methods in the
# BLT Graph package. If you want to develop your own 
# program, this example might be a good starting point.
# 

from Tkinter import *        # The Tk package
import Pmw                   # The Python MegaWidget package
import math                  # import the sin-function

master = Tk()                # make a Tk root window
ncurves = 4                  # draw 4 curves
npoints = 32                 # use 32 points on each curve


if not Pmw.Blt.haveblt(master):     # is Blt installed?
   print("BLT is not installed!")

else:
   vector_x = []  # vector for the x values in the curves
   vector_y = []  

   for y in range(ncurves):
      vector_y.append([])  # make vector_y as a list of lists (list of curves)

   for x in range(npoints+1):                    # for each point...
      vector_x.append(x*0.1)                     # compute x value

      # fill vectors with cool graphs
      for c in range(ncurves):                   # for each curve...
         vector_y[c].append(math.sin(c*x*0.1))   # compute y value

   g = Pmw.Blt.Graph(master)                     # make a new graph area
   g.pack(expand=1, fill='both')

   for c in range(ncurves):                      # for each curve...
      curvename = 'sin(' + str(c) +'x)'          # make a curvename
      g.line_create(curvename,                   # and create the graph
                    xdata=tuple(vector_x),       # with x-data,
                    ydata=tuple(vector_y[c]),    # and  y-data
                    symbol='')                   # ...and no markers
   
   g.configure(title='Hello World of sine functions') # enter a title

   
   master.mainloop()                             # ...and wait for input
