#!/bin/sh

""":"
exec python $0 ${1+"$@"}
"""

# ---------------------- HelloPens.py ----------------------
# 
# This program demonstrates all methods available for pens.
# Note that this program does not do anything useful;
# its purpose is to try out functionality only.
# 


from Tkinter import *        # The Tk package
import Pmw                   # The Python MegaWidget package
import math                  # import the sin-function

master = Tk()                # build Tk-environment
ncurves = 4                  # draw 4 curves
npoints = 32                 # use 32 points on each curve


if not Pmw.Blt.haveblt(master):     # Is Blt installed?
   print("BLT is not installed!")

else:
   vector_x = []   # make vector for x-axis
   vector_y = []

   for y in range(ncurves):
     vector_y.append([])                   

   for x in range(npoints+1):              
      vector_x.append(x*0.1)               

      # fill vectors with cool graphs
      for c in range(ncurves):             
         vector_y[c].append(math.sin(c*x*0.1))

   g = Pmw.Blt.Graph(master)                  
   g.pack(expand=1, fill='both')

   for c in range(ncurves):                   
      curvename = 'sin(' + str(c) +'x)'       
      g.line_create(curvename,                
                    xdata=tuple(vector_x),   
                    ydata=tuple(vector_y[c]),
                    symbol='')               
   
   g.configure(title='Hello Pens')            
   
   ############################# pen_create ###########################
   customPen = g.pen_create("custom", 
                            symbol="circle", 
                            pixels=7,
                            linewidth=2,
                            color="green")
   			     
   g.element_configure("sin(1x)", pen="custom") # use this pen on sin(x)
   
   ############################### pen_cget #############################
   symbol = g.pen_cget("custom", "symbol")
   print "Current symboltype is:", symbol
   

   ############################# pen_configure ##########################
   all = g.pen_configure("custom")           # get all options
   
   for key in all.keys():
      print key, "=", g.pen_cget("custom", key) # display all options

   # set outline color of the two pens "custom" and "activeLine"
   # (activeLine is a predefined pen)
   g.pen_configure(("custom", "activeLine"), outline="red")
   
  
   ############################### pen_delete ###########################
   g.pen_delete("custom") # won't be deleted since it is in use.
                          # yet, it won't be found by e.g. pen_names(...)
   
   ############################### pen_names ############################
   all = g.pen_names("*") # get all pens.
   
   print "All current pens:",
   for name in all:
       print name, 
   print "\n"
   
   master.mainloop()



