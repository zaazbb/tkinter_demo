#!/bin/sh

""":"
exec python $0 ${1+"$@"}
"""

# ---------------------- HelloGrid.py ----------------------
# 
# This program demonstrates all methods available for the grid.
# Note that this program does not do anything useful;
# its purpose is to try out functionality only.
# 


from Tkinter import *        # The Tk package
import Pmw                   # The Python MegaWidget package
import math                  # import the sin-function

master = Tk()                # build Tk-environment
ncurves = 4                  # draw 4 curves
npoints = 32                 # use 32 points on each curve


if not Pmw.Blt.haveblt(master):     # Is Blt installed?
   print("BLT is not installed!")

else:
   vector_x = []   # make vector for x-axis
   vector_y = []

   for y in range(ncurves):
     vector_y.append([])                    

   for x in range(npoints+1):               
      vector_x.append(x*0.1)                

      # fill vectors with cool graphs
      for c in range(ncurves):              
         vector_y[c].append(math.sin(c*x*0.1))

   g = Pmw.Blt.Graph(master)           
   g.pack(expand=1, fill='both')

   for c in range(ncurves):                  
      curvename = 'sin(' + str(c) +'x)'      
      g.line_create(curvename,               
                     xdata=tuple(vector_x),     
                     ydata=tuple(vector_y[c]),  
                     symbol='')                 
   
   g.configure(title='Hello Grids')             
   

   ############################# grid_cget #############################
   dashes = g.grid_cget("dashes")
   print "dashes:", dashes
   
   ############################# grid_configure ########################
   g.grid_configure(hide=0,                    # show 
                    color="blue",              # with blue color
                    dashes=15)                 # and large dashes
   		     
   ############################### grid_off ############################
   g.grid_off() # turn grids off again.
   
   ############################## grid_toggle ##########################
   g.grid_toggle() # toggle it back on
   
   ################################ grid_on ############################
   g.grid_on() # it's already on, so this won't have any effect.   

	   
   master.mainloop()



