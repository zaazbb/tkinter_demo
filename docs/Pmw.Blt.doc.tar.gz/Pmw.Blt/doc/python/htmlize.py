# Python script for typesetting a Python source file in HTML with
# some use of colors etc.
# Usage: htmlize.py file1.py file2.py ...
# Results in html/file1.html, html/file2.html and so on.
# Warning: this script is tailored to the Pmw.Blt examples.

import re
import glob
import sys

def keyword( keywords, line ):
    
    for kw in keywords:
        new = re.sub( "(" + kw +r"\s)", r'<font color="#ff9900">\1</font>', line )
    	if new <> None: line = new
    return line
    
try:
    filelist = sys.argv[1:]
except:
    print "Usage",sys.argv[0],": file1 file2 ..."
    sys.exit(1)

for filename in filelist:
    print "making nice HTML listing of", filename
    headerPending = 0
    file = open( filename, 'r' )
    out  = open( "html/" + filename[:-2] + "html", "w" )
    out.write( "<html><head></head><body bgcolor='#ffffff'><pre>" )
	            
    for line in file.readlines():
        
        # first, take special care of header
        if line == '""":"\n':
            out.write( '<font color="#009900">""":"\n'  )
            headerPending = 1
            continue
            
        if line == '"""\n':
            out.write( '"""</font>\n' )
            headerPending = 0
            continue
            
        if headerPending:
            out.write( line )
            continue
            
        # otherwise handle the rest of the file.
        
        line = re.sub( "<", "&lt;", line )
        line = re.sub( ">", "&gt;", line )
        line = re.sub( "\t", "        ", line )

        comment = None
        notcomment = re.sub( r"([^#]*)(#[ !#].*)\n", r'\1', line )
        if notcomment <> line:
           comment = re.sub( r"([^#]*)(#[ !#].*)\n", r'<font color="#cc0000">\2</font>\n', line )
           line    = notcomment
            
        line = re.sub( r'"([^">]*)"', r'<font color="#009900">&quot;\1&quot;</font>', line )
        line = re.sub( r"('[^']*')", r'<font color="#009900">\1</font>', line )
        line = re.sub( "(def) ([a-zA-Z_0-9]*)(.*)", r'<font color="#ff9900">\1</font> <font color="#0000ff">\2</font>\3', line )
            
            
        # Paint keywords, but avoid two typical traps... 
        if not re.search( "BLT is not installed", line ) and not re.search( "does not exist", line ):
              line = keyword( ( "^from", "^import", "global", "elif", "if", "else:", "for", "in", "not" ), line )

        if comment <> None:
            line = line + comment
            
        out.write( line )

    out.write( "</pre>" )
    out.close()
    file.close()
